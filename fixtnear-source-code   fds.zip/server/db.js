import { DatabaseSync } from 'node:sqlite';

export const sampleProviders = [
  {id:1,name:'Suresh Kumar',business:'Suresh Plumbing Works',category:'Plumbing',emoji:'👨🏽‍🔧',rating:4.8,reviews:186,jobs:264,years:9,km:1.2,available:true,price:150,bio:'Thoughtful plumbing repairs for kitchens, bathrooms, and everything in between.',tags:['Tap replacement','Leak repair','Pipe fitting'],rates:[['Tap replacement','₹150'],['Leak inspection','₹149'],['Pipe repair','From ₹350']]},
  {id:2,name:'Ramesh Electricals',business:'Ramesh Electricals',category:'Electrical',emoji:'👨🏻‍🔧',rating:4.9,reviews:142,jobs:218,years:11,km:2.1,available:true,price:180,bio:'Safe, tidy electrical work with clear estimates before the work starts.',tags:['Fans & lights','Wiring','Switches'],rates:[['Ceiling fan installation','₹150'],['Switch replacement','₹120'],['Wiring diagnosis','₹149']]},
  {id:3,name:'Modern AC Solutions',business:'Modern AC Solutions',category:'AC & cooling',emoji:'🧑🏽‍🔧',rating:4.7,reviews:98,jobs:173,years:7,km:3.4,available:true,price:299,bio:'Cooling, maintenance, and installation from experienced neighborhood technicians.',tags:['AC service','Installation','Refrigerator'],rates:[['AC inspection','₹149'],['Filter service','₹299'],['Installation','From ₹899']]},
  {id:4,name:'Sharma Plumbing Co.',business:'Sharma Plumbing Co.',category:'Plumbing',emoji:'👨🏻‍🔧',rating:4.6,reviews:114,jobs:192,years:8,km:3.1,available:false,price:130,bio:'Reliable repairs and installations, with parts explained before fitting.',tags:['Tap replacement','Drain clearing','Water heaters'],rates:[['Tap replacement','₹130'],['Drain clearing','From ₹300'],['Water heater check','₹149']]},
  {id:5,name:'Anita Home Repairs',business:'Anita Home Repairs',category:'Carpentry',emoji:'👩🏽‍🔧',rating:4.9,reviews:77,jobs:129,years:6,km:1.8,available:true,price:250,bio:'Careful carpentry and small home repairs, finished neatly and on time.',tags:['Door repair','Furniture','Shelves'],rates:[['Door adjustment','₹250'],['Shelf installation','From ₹350'],['Furniture repair','From ₹300']]},
  {id:6,name:'BrightWire Services',business:'BrightWire Services',category:'Electrical',emoji:'👨🏽‍🔧',rating:4.5,reviews:88,jobs:148,years:5,km:4.2,available:true,price:160,bio:'Friendly help for lighting, fans, switches, and everyday electrical issues.',tags:['Lights','Fan installation','Switches'],rates:[['Light fitting','₹160'],['Fan installation','₹250'],['Switch replacement','₹120']]},
  {id:7,name:'CoolNest Appliance Care',business:'CoolNest Appliance Care',category:'Appliance repair',emoji:'👨🏻‍🔧',rating:4.8,reviews:105,jobs:163,years:8,km:2.9,available:true,price:199,bio:'Home appliance repairs with a clear diagnosis and parts estimate.',tags:['Washing machine','Fridge','Microwave'],rates:[['Appliance diagnosis','₹149'],['Washing machine visit','₹199'],['Microwave repair','From ₹350']]},
  {id:8,name:'Kavita Color & Coat',business:'Kavita Color & Coat',category:'Painting',emoji:'👩🏽‍🎨',rating:4.7,reviews:69,jobs:111,years:7,km:4.6,available:false,price:450,bio:'Smooth, clean painting and touch-ups that bring a little life back to your rooms.',tags:['Touch-ups','Interior paint','Waterproofing'],rates:[['Room touch-up','From ₹450'],['Wall painting','From ₹12/sq ft'],['Inspection','₹149']]},
  {id:9,name:'PipeWise Services',business:'PipeWise Services',category:'Plumbing',emoji:'👨🏽‍🔧',rating:4.4,reviews:52,jobs:96,years:4,km:5.1,available:true,price:120,bio:'Quick local plumbing fixes with upfront pricing and careful cleanup.',tags:['Tap replacement','Flush repair','Leak repair'],rates:[['Tap replacement','₹120'],['Flush repair','₹250'],['Leak inspection','₹149']]},
  {id:10,name:'Aarav Woodworks',business:'Aarav Woodworks',category:'Carpentry',emoji:'👨🏻‍🔧',rating:4.8,reviews:91,jobs:155,years:10,km:3.8,available:true,price:300,bio:'Custom fixes and practical furniture repairs for homes and apartments.',tags:['Furniture','Door locks','Cabinet repair'],rates:[['Cabinet repair','From ₹300'],['Door lock fitting','₹350'],['Shelf installation','₹400']]},
  {id:11,name:'QuickFix Appliances',business:'QuickFix Appliances',category:'Appliance repair',emoji:'🧑🏻‍🔧',rating:4.6,reviews:63,jobs:104,years:6,km:1.5,available:true,price:180,bio:'Prompt appliance diagnosis and repairs from a familiar local face.',tags:['Fridge','Washing machine','Water purifier'],rates:[['Appliance diagnosis','₹149'],['Water purifier service','₹180'],['Fridge visit','₹199']]},
  {id:12,name:'BreezeCare AC & Cooling',business:'BreezeCare AC & Cooling',category:'AC & cooling',emoji:'👨🏽‍🔧',rating:4.9,reviews:121,jobs:204,years:12,km:2.6,available:false,price:349,bio:'Expert AC and cooling support, from seasonal care to installation.',tags:['AC service','Cooling issue','Installation'],rates:[['AC inspection','₹149'],['AC service','₹349'],['Installation','From ₹999']]}
];

export function createDatabase(path = ':memory:') {
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS providers (id INTEGER PRIMARY KEY, data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY, provider_id INTEGER NOT NULL REFERENCES providers(id),
      name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL, service TEXT NOT NULL,
      date TEXT NOT NULL, time TEXT NOT NULL, issue TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL CHECK(status IN ('Requested','Accepted','In Progress','Completed')),
      created TEXT NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS active_slot ON bookings(provider_id,date,time)
      WHERE status <> 'Completed';
    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT, booking_id TEXT UNIQUE NOT NULL REFERENCES bookings(id),
      stars INTEGER NOT NULL CHECK(stars BETWEEN 1 AND 5), text TEXT NOT NULL, created TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS quotes (
      booking_id TEXT PRIMARY KEY NOT NULL REFERENCES bookings(id),
      labor INTEGER NOT NULL CHECK(labor BETWEEN 0 AND 100000),
      parts INTEGER NOT NULL CHECK(parts BETWEEN 0 AND 100000),
      notes TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('Pending','Approved','Rejected')),
      created TEXT NOT NULL
    );`);
  const count = db.prepare('SELECT COUNT(*) AS n FROM providers').get().n;
  if (!count) {
    const insert = db.prepare('INSERT INTO providers(id,data) VALUES (?,?)');
    for (const p of sampleProviders) insert.run(p.id, JSON.stringify(p));
  }
  return db;
}

export function listProviders(db) { return db.prepare('SELECT data FROM providers').all().map(r => JSON.parse(r.data)); }
