import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { createDatabase, listProviders } from './db.js';
import { validateBooking, validateReview, timeSlots } from './validation.js';
import { login, logout, requireTechnician } from './auth.js';

const here = path.dirname(fileURLToPath(import.meta.url));
export function createApp({ db = createDatabase() } = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');next()});
  app.use(express.json({limit:'20kb'}));
  app.use(cookieParser());
  app.use(express.static(path.join(here,'..','public')));
  app.get('/api/categories', (req,res)=>res.json([...new Set(listProviders(db).map(p=>p.category))]));
  app.get('/api/providers', (req,res)=>{
    let items=listProviders(db);const q=String(req.query.q??'').trim().toLowerCase();
    if(req.query.category)items=items.filter(p=>p.category===req.query.category);
    if(q)items=items.filter(p=>[p.name,p.business,p.category,...p.tags].join(' ').toLowerCase().includes(q));
    if(req.query.filter==='Nearby')items=items.filter(p=>p.km<3);
    if(req.query.filter==='Top rated')items=items.filter(p=>p.rating>=4.8);
    if(req.query.filter==='Available today')items=items.filter(p=>p.available);
    if(req.query.sort==='rating')items.sort((a,b)=>b.rating-a.rating);
    if(req.query.sort==='price')items.sort((a,b)=>a.price-b.price);
    res.json(items);
  });
  app.get('/api/providers/:id',(req,res)=>{const p=listProviders(db).find(x=>x.id===Number(req.params.id));p?res.json(p):res.status(404).json({error:'Provider not found.'})});
  app.post('/api/bookings',(req,res)=>{
    const checked=validateBooking(req.body??{},listProviders(db));
    if(!checked.valid)return res.status(400).json({error:'Please correct the booking details.',fields:checked.errors});
    const b=checked.normalized;const id=randomUUID();
    try{db.prepare(`INSERT INTO bookings(id,provider_id,name,phone,address,service,date,time,issue,status,created) VALUES(?,?,?,?,?,?,?,?,?,'Requested',?)`).run(id,b.providerId,b.name,b.phone,b.address,b.service,b.date,b.time,b.issue,new Date().toISOString());
      res.status(201).json({id,providerId:b.providerId,service:b.service,date:b.date,time:b.time,status:'Requested'});
    }catch(e){if(String(e.message).includes('active_slot')||String(e.message).includes('UNIQUE constraint failed'))return res.status(409).json({error:'That technician already has an active booking for this time. Choose another slot.'});throw e;}
  });
  app.get('/api/bookings',(req,res)=>{
    const ids=String(req.query.ids??'').split(',').filter(x=>/^[0-9a-f-]{36}$/i.test(x)).slice(0,30);
    if(!ids.length)return res.json([]);
    const marks=ids.map(()=>'?').join(',');
    const rows=db.prepare(`SELECT b.id,b.provider_id,b.service,b.date,b.time,b.status,q.labor,q.parts,q.notes AS quoteNotes,q.status AS quoteStatus FROM bookings b LEFT JOIN quotes q ON q.booking_id=b.id WHERE b.id IN (${marks}) ORDER BY b.created DESC`).all(...ids);
    res.json(rows);
  });
  app.post('/api/bookings/:id/quote-decision',(req,res)=>{
    const decision=req.body?.decision==='approve'?'Approved':req.body?.decision==='reject'?'Rejected':null;
    if(!decision)return res.status(400).json({error:'Choose approve or reject.'});
    const quote=db.prepare('SELECT status FROM quotes WHERE booking_id=?').get(req.params.id);
    if(!quote)return res.status(404).json({error:'No repair quote was found.'});
    if(quote.status!=='Pending')return res.status(409).json({error:'This quote has already been answered.'});
    db.prepare('UPDATE quotes SET status=? WHERE booking_id=?').run(decision,req.params.id);
    res.json({status:decision});
  });
  app.post('/api/reviews/:bookingId',(req,res)=>{
    const checked=validateReview(req.body??{});if(!checked.valid)return res.status(400).json({error:'Please correct the review.',fields:checked.errors});
    const booking=db.prepare('SELECT id,status FROM bookings WHERE id=?').get(req.params.bookingId);
    if(!booking)return res.status(404).json({error:'Booking not found.'});
    if(booking.status!=='Completed')return res.status(409).json({error:'A review can be submitted after the job is completed.'});
    try{const {stars,text}=checked.normalized;db.prepare('INSERT INTO reviews(booking_id,stars,text,created) VALUES(?,?,?,?)').run(booking.id,stars,text,new Date().toISOString());res.status(201).json({ok:true});}
    catch(e){if(String(e.message).includes('UNIQUE'))return res.status(409).json({error:'A review has already been submitted for this booking.'});throw e;}
  });
  app.post('/api/auth/login',login);app.delete('/api/auth/logout',logout);
  app.get('/api/technician/bookings',requireTechnician,(req,res)=>res.json(db.prepare(`SELECT b.id,b.provider_id AS providerId,b.name,b.phone,b.address,b.service,b.date,b.time,b.issue,b.status,q.labor,q.parts,q.notes AS quoteNotes,q.status AS quoteStatus FROM bookings b LEFT JOIN quotes q ON q.booking_id=b.id ORDER BY b.created DESC`).all()));
  app.post('/api/technician/bookings/:id/quote',requireTechnician,(req,res)=>{
    const b=db.prepare('SELECT id,status FROM bookings WHERE id=?').get(req.params.id);
    if(!b)return res.status(404).json({error:'Booking not found.'});
    if(b.status!=='Accepted')return res.status(409).json({error:'A quote can be sent after you accept the booking.'});
    const labor=Number(req.body?.labor),parts=Number(req.body?.parts),notes=String(req.body?.notes??'').trim();
    if(!Number.isInteger(labor)||labor<0||labor>100000||!Number.isInteger(parts)||parts<0||parts>100000||notes.length<5||notes.length>500)return res.status(400).json({error:'Enter labor and parts amounts from ₹0 to ₹100,000 and a 5–500 character explanation.'});
    db.prepare(`INSERT INTO quotes(booking_id,labor,parts,notes,status,created) VALUES(?,?,?,?,'Pending',?) ON CONFLICT(booking_id) DO UPDATE SET labor=excluded.labor,parts=excluded.parts,notes=excluded.notes,status='Pending',created=excluded.created`).run(b.id,labor,parts,notes,new Date().toISOString());
    res.status(201).json({bookingId:b.id,labor,parts,total:labor+parts,status:'Pending'});
  });
  app.patch('/api/technician/bookings/:id/status',requireTechnician,(req,res)=>{
    const transitions={Requested:'Accepted',Accepted:'In Progress','In Progress':'Completed'};
    const b=db.prepare('SELECT id,status,time,provider_id AS providerId FROM bookings WHERE id=?').get(req.params.id);
    if(!b)return res.status(404).json({error:'Booking not found.'});
    if(transitions[b.status]!==req.body?.status)return res.status(409).json({error:`Cannot change status from ${b.status} to ${req.body?.status}.`});
    if(req.body.status==='In Progress'){
      const quote=db.prepare('SELECT status FROM quotes WHERE booking_id=?').get(b.id);
      if(quote?.status!=='Approved')return res.status(409).json({error:'The customer must approve the repair quote before work can start.'});
    }
    db.prepare('UPDATE bookings SET status=? WHERE id=?').run(req.body.status,b.id);
    res.json({...b,status:req.body.status});
  });
  app.use('/api',(req,res)=>res.status(404).json({error:'API route not found.'}));
  app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Unexpected server error.'})});
  return app;
}

if(process.argv[1]===fileURLToPath(import.meta.url)){
  const dbPath=process.env.DATABASE_PATH||path.join(here,'..','data','fixtnear.sqlite');
  const fs=(await import('node:fs')).default;fs.mkdirSync(path.dirname(dbPath),{recursive:true});
  const db=createDatabase(dbPath);const port=Number(process.env.PORT)||3000;
  createApp({db}).listen(port,()=>console.log(`FixItNear running at http://localhost:${port}`));
}
