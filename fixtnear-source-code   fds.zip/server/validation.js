export const timeSlots = [
  '10:00 AM – 12:00 PM', '12:00 PM – 2:00 PM',
  '2:00 PM – 4:00 PM', '4:00 PM – 6:00 PM'
];

export function validateBooking(input, providers) {
  const errors = {};
  const phone = String(input.phone ?? '').replace(/[\s()+-]/g, '');
  const date = String(input.date ?? '');
  if (!Number.isInteger(Number(input.providerId)) || !providers.some(p => p.id === Number(input.providerId))) errors.providerId = 'Choose a valid technician.';
  if (String(input.name ?? '').trim().length < 2) errors.name = 'Enter your name.';
  if (!/^\d{10,15}$/.test(phone)) errors.phone = 'Enter a valid phone number with 10 to 15 digits.';
  if (String(input.address ?? '').trim().length < 5) errors.address = 'Enter a complete service address.';
  if (String(input.service ?? '').trim().length < 2 || String(input.service).length > 100) errors.service = 'Enter a valid service.';
  const parsedDate = new Date(`${date}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(parsedDate.valueOf()) || parsedDate.toISOString().slice(0,10)!==date || date < new Date().toISOString().slice(0, 10)) errors.date = 'Choose today or a future date.';
  if (!timeSlots.includes(input.time)) errors.time = 'Choose an available two-hour time slot.';
  if (String(input.issue ?? '').trim().length > 1000) errors.issue = 'Issue description must be under 1000 characters.';
  return { valid: Object.keys(errors).length === 0, errors, normalized: { ...input, providerId: Number(input.providerId), phone, name: String(input.name ?? '').trim(), address: String(input.address ?? '').trim(), service: String(input.service ?? '').trim(), issue: String(input.issue ?? '').trim() } };
}

export function validateReview(input) {
  const stars = Number(input.stars);
  const text = String(input.text ?? '').trim();
  const errors = {};
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) errors.stars = 'Choose a rating from 1 to 5.';
  if (text.length < 3 || text.length > 1000) errors.text = 'Write a review between 3 and 1000 characters.';
  return { valid: Object.keys(errors).length === 0, errors, normalized: { stars, text } };
}
