import { createHmac, timingSafeEqual } from 'node:crypto';

const secret = process.env.SESSION_SECRET;
const password = process.env.TECHNICIAN_PASSWORD;
const cookieName = 'fixtnear_session';

function sign(value) { return createHmac('sha256', secret).update(value).digest('base64url'); }
export function authReady() { return Boolean(secret && secret.length >= 32 && password && password.length >= 12); }
export function login(req, res) {
  if (!authReady()) return res.status(503).json({error:'Set SESSION_SECRET (32+ characters) and TECHNICIAN_PASSWORD (12+ characters) before enabling technician login.'});
  const submitted = Buffer.from(String(req.body?.password ?? ''));
  const expected = Buffer.from(password);
  if (submitted.length !== expected.length || !timingSafeEqual(submitted, expected)) return res.status(401).json({error:'Incorrect technician password.'});
  const payload = Buffer.from(JSON.stringify({exp:Date.now()+8*60*60*1000})).toString('base64url');
  res.cookie(cookieName, `${payload}.${sign(payload)}`, {httpOnly:true,sameSite:'strict',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000,path:'/'});
  return res.json({ok:true});
}
export function logout(req,res) { res.clearCookie(cookieName,{httpOnly:true,sameSite:'strict',path:'/'});res.json({ok:true}); }
export function requireTechnician(req,res,next) {
  if (!authReady()) return res.status(503).json({error:'Technician authentication is not configured.'});
  const raw = req.cookies?.[cookieName] ?? '';
  const [payload,signature] = raw.split('.');
  if (!payload || !signature) return res.status(401).json({error:'Technician login required.'});
  const expected = Buffer.from(sign(payload)); const provided = Buffer.from(signature);
  if (expected.length !== provided.length || !timingSafeEqual(expected,provided)) return res.status(401).json({error:'Invalid technician session.'});
  try { if (JSON.parse(Buffer.from(payload,'base64url').toString()).exp < Date.now()) throw new Error('expired'); }
  catch { return res.status(401).json({error:'Technician session expired. Log in again.'}); }
  next();
}
