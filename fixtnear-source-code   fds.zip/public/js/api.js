async function request(url, options = {}) {
  const response = await fetch(url, { credentials: 'same-origin', headers: { 'Content-Type': 'application/json', ...options.headers }, ...options });
  const body = response.status === 204 ? null : await response.json().catch(() => ({}));
  if (!response.ok) { const error = new Error(body?.error || 'The request could not be completed.'); error.status=response.status; error.fields=body?.fields||{}; throw error; }
  return body;
}
export const api = {
  providers: params => request(`/api/providers?${new URLSearchParams(params)}`),
  categories: () => request('/api/categories'),
  provider: id => request(`/api/providers/${id}`),
  createBooking: data => request('/api/bookings',{method:'POST',body:JSON.stringify(data)}),
  customerBookings: ids => request(`/api/bookings?ids=${encodeURIComponent(ids.join(','))}`),
  login: password => request('/api/auth/login',{method:'POST',body:JSON.stringify({password})}),
  logout: () => request('/api/auth/logout',{method:'DELETE'}),
  technicianBookings: () => request('/api/technician/bookings'),
  updateStatus: (id,status) => request(`/api/technician/bookings/${id}/status`,{method:'PATCH',body:JSON.stringify({status})}),
  review: (id,data) => request(`/api/reviews/${id}`,{method:'POST',body:JSON.stringify(data)}),
  quote: (id,data) => request(`/api/technician/bookings/${id}/quote`,{method:'POST',body:JSON.stringify(data)}),
  quoteDecision: (id,decision) => request(`/api/bookings/${id}/quote-decision`,{method:'POST',body:JSON.stringify({decision})})
};
