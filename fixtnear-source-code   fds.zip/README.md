# FixItNear

FixItNear is a home-services marketplace prototype. It uses an Express API and SQLite database for providers, bookings, reviews, server-side validation, and protected technician actions. Technicians submit an itemized labor-and-parts estimate; the customer must approve it before work can start. The browser uses separate API, rendering, and page-controller modules.

## Requirements

- Node.js 24 or later
- npm
- A modern browser

## Run locally

1. Extract the project ZIP and open its folder in a terminal.
2. Install the dependency: `npm install`
3. Set technician credentials in PowerShell:

   ```powershell
   $env:SESSION_SECRET = 'use-a-random-secret-at-least-32-characters-long'
   $env:TECHNICIAN_PASSWORD = 'choose-a-password-at-least-12-characters'
   ```

4. Start the app: `npm start`
5. Open `http://localhost:3000` in your browser.

SQLite data is created in `data/fixtnear.sqlite` on first run. The database file is runtime data and is not part of the source ZIP.

## Run the automated tests

```sh
npm test
```

The tests use an in-memory SQLite database and do not modify the local project database.

## Project structure

- `public/` — HTML, CSS, and browser JavaScript modules
- `server/` — Express routes, SQLite setup, authentication, and validation
- `tests/` — API and validation integration tests
- `package.json` — startup, test commands, and dependency list

This is still a prototype with sample provider records. Technician login is configured locally through environment variables. It does not send real bookings or process payments.
